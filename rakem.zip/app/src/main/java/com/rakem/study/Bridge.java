package com.rakem.study;

import android.app.Activity;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;

/** Exposed to the web page as window.RakemNative. */
public class Bridge {
    private final Activity activity;

    Bridge(Activity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void setAt(int id, String title, String body, double atMillis) {
        Scheduler.save(activity, id, title, body, 0, (long) atMillis, 0, 0, 0);
        Scheduler.arm(activity, id);
    }

    @JavascriptInterface
    public void setWeekly(int id, String title, String body, int weekday, int hour, int minute) {
        Scheduler.save(activity, id, title, body, 1, 0L, weekday, hour, minute);
        Scheduler.arm(activity, id);
    }

    @JavascriptInterface
    public void cancel(int id) {
        Scheduler.cancel(activity, id);
    }

    @JavascriptInterface
    public void cancelFrom(int minId) {
        Scheduler.cancelFrom(activity, minId);
    }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (on) {
                    activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } else {
                    activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            }
        });
    }
}
