package com.rakem.study;

import android.app.Activity;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;

/** Exposed to the web page as window.RakemNative. */
public class Bridge {
    private final Activity activity;

    Bridge(Activity activity) {
        this.activity = activity;
    }

    /** alarm = true: rings loudly until stopped. false: ordinary notification. */
    @JavascriptInterface
    public void setAt(int id, String title, String body, double atMillis, boolean alarm) {
        Scheduler.save(activity, id, title, body, 0, (long) atMillis, 0, 0, 0, alarm);
        Scheduler.arm(activity, id);
    }

    @JavascriptInterface
    public void setWeekly(int id, String title, String body, int weekday, int hour, int minute, boolean alarm) {
        Scheduler.save(activity, id, title, body, 1, 0L, weekday, hour, minute, alarm);
        Scheduler.arm(activity, id);
    }

    @JavascriptInterface
    public void cancel(int id) {
        Scheduler.cancel(activity, id);
    }

    @JavascriptInterface
    public void cancelFrom(int minId) {
        Scheduler.cancelFrom(activity, minId);
    }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (on) {
                    activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } else {
                    activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            }
        });
    }

    /** Rings right now (used for the "test alarm" button and when the app itself needs to ring). */
    @JavascriptInterface
    public void ringNow(String title, String body) {
        try {
            AlarmService.start(activity, title, body);
        } catch (Exception ignored) {
        }
    }

    @JavascriptInterface
    public void stopAlarm() {
        AlarmService.stop(activity);
    }

    /** kind: "alarm" or "notif". Opens the system file picker; the result arrives in window.rakemSoundPicked. */
    @JavascriptInterface
    public void pickSound(final String kind) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (activity instanceof MainActivity) {
                    ((MainActivity) activity).pickSound(kind);
                }
            }
        });
    }

    @JavascriptInterface
    public void clearSound(String kind) {
        Tones.clear(activity, kind);
    }

    /** Display name of the user's chosen sound, or "" when the default is used. */
    @JavascriptInterface
    public String soundName(String kind) {
        return Tones.name(activity, kind);
    }

    /** Plays the user's notification sound once so they can hear it. */
    @JavascriptInterface
    public void previewNotifSound() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Tones.has(activity, Tones.NOTIF)) {
                    Tones.playNotifOnce(activity, null);
                }
            }
        });
    }
}
