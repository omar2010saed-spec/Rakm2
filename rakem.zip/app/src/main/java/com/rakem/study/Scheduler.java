package com.rakem.study;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/** Stores scheduled notifications and arms them with AlarmManager. */
final class Scheduler {

    static final String CH_REMIND = "rakem_remind";
    static final String CH_TIMER = "rakem_timer";
    static final String CH_RING = "rakem_ring";
    static final String CH_QUIET = "rakem_quiet";
    private static final String PREFS = "rakem_sched";
    private static final String ACTION = "com.rakem.study.ALARM";

    private Scheduler() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void ensureChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        long[] vib = new long[]{0, 300, 150, 300};
        if (nm.getNotificationChannel(CH_REMIND) == null) {
            NotificationChannel ch = new NotificationChannel(CH_REMIND, "تذكيرات المذاكرة", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_RING) == null) {
            // the ringing itself is played by AlarmService; this channel only carries the notification
            NotificationChannel ch = new NotificationChannel(CH_RING, "المنبه (يرن حتى الإيقاف)", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.enableVibration(false);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_QUIET) == null) {
            // used when the user picked their own notification sound (we play it ourselves)
            NotificationChannel ch = new NotificationChannel(CH_QUIET, "إشعارات بصوتك الخاص", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_TIMER) == null) {
            NotificationChannel ch = new NotificationChannel(CH_TIMER, "انتهاء المؤقت", NotificationManager.IMPORTANCE_HIGH);
            Uri snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (snd == null) {
                snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            ch.setSound(snd, aa);
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            nm.createNotificationChannel(ch);
        }
    }

    /** type 0 = one-shot at epoch millis, type 1 = weekly (Calendar weekday 1=Sunday..7=Saturday). */
    static void save(Context c, int id, String title, String body, int type, long at, int weekday, int hour, int minute, boolean alarm) {
        try {
            JSONObject o = new JSONObject();
            o.put("title", title);
            o.put("body", body);
            o.put("type", type);
            o.put("at", at);
            o.put("wd", weekday);
            o.put("h", hour);
            o.put("m", minute);
            o.put("alarm", alarm);
            prefs(c).edit().putString("n" + id, o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static JSONObject load(Context c, int id) {
        try {
            String s = prefs(c).getString("n" + id, null);
            return s == null ? null : new JSONObject(s);
        } catch (Exception e) {
            return null;
        }
    }

    private static PendingIntent pending(Context c, int id) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(ACTION);
        i.setData(Uri.parse("rakem://alarm/" + id));
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long nextWeekly(JSONObject o) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, o.optInt("wd", 1));
        cal.set(Calendar.HOUR_OF_DAY, o.optInt("h", 0));
        cal.set(Calendar.MINUTE, o.optInt("m", 0));
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        long limit = System.currentTimeMillis() + 30000L;
        if (cal.getTimeInMillis() <= limit) {
            cal.add(Calendar.DAY_OF_YEAR, 7);
        }
        return cal.getTimeInMillis();
    }

    /** Arms the alarm for a stored entry. Returns false if the entry is gone or already in the past. */
    static boolean arm(Context c, int id) {
        JSONObject o = load(c, id);
        if (o == null) {
            return false;
        }
        long when;
        if (o.optInt("type", 0) == 1) {
            when = nextWeekly(o);
        } else {
            when = o.optLong("at", 0L);
            if (when <= System.currentTimeMillis()) {
                prefs(c).edit().remove("n" + id).apply();
                return false;
            }
        }
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return false;
        }
        PendingIntent pi = pending(c, id);
        try {
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception e) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } catch (Exception ignored) {
            }
        }
        return true;
    }

    static void cancel(Context c, int id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(pending(c, id));
        }
        prefs(c).edit().remove("n" + id).apply();
    }

    static void cancelFrom(Context c, int minId) {
        List<Integer> ids = new ArrayList<Integer>();
        Map<String, ?> all = prefs(c).getAll();
        for (String k : all.keySet()) {
            if (k.startsWith("n")) {
                try {
                    int id = Integer.parseInt(k.substring(1));
                    if (id >= minId) {
                        ids.add(id);
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        }
        for (int id : ids) {
            cancel(c, id);
        }
    }

    static void armAll(Context c) {
        List<Integer> ids = new ArrayList<Integer>();
        Map<String, ?> all = prefs(c).getAll();
        for (String k : all.keySet()) {
            if (k.startsWith("n")) {
                try {
                    ids.add(Integer.parseInt(k.substring(1)));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        for (int id : ids) {
            arm(c, id);
        }
    }

    static void show(Context c, int id, String title, String body) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean timer = id < 1000;
        String channel = timer ? CH_TIMER : CH_REMIND;
        if (Tones.has(c, Tones.NOTIF)) {
            channel = CH_QUIET;
        }
        Notification.Builder b = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(content)
                .setCategory(timer ? Notification.CATEGORY_ALARM : Notification.CATEGORY_REMINDER)
                .setWhen(System.currentTimeMillis());
        nm.notify(id, b.build());
    }
}
