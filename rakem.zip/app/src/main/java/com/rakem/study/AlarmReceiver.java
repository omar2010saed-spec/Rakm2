package com.rakem.study;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", -1);
        if (id < 0) {
            return;
        }
        JSONObject o = Scheduler.load(context, id);
        if (o == null) {
            return;
        }
        Scheduler.show(context, id, o.optString("title", ""), o.optString("body", ""));
        if (o.optInt("type", 0) == 1) {
            Scheduler.arm(context, id);
        } else {
            Scheduler.cancel(context, id);
        }
    }
}
