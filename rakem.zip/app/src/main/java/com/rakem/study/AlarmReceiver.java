package com.rakem.study;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context context, Intent intent) {
        int id = intent.getIntExtra("id", -1);
        if (id < 0) {
            return;
        }
        JSONObject o = Scheduler.load(context, id);
        if (o == null) {
            return;
        }
        String title = o.optString("title", "");
        String body = o.optString("body", "");
        boolean alarm = o.optBoolean("alarm", id < 1000);

        // re-arm the next week first, so a failure below never loses the schedule
        boolean weekly = o.optInt("type", 0) == 1;
        if (weekly) {
            Scheduler.arm(context, id);
        } else {
            Scheduler.cancel(context, id);
        }

        if (alarm) {
            try {
                AlarmService.start(context, title, body);
                return;
            } catch (Exception e) {
                // could not start the ringing service: fall back to a normal loud notification
            }
        }

        Scheduler.show(context, id, title, body);
        if (!alarm && Tones.has(context, Tones.NOTIF)) {
            final PendingResult pr = goAsync();
            Tones.playNotifOnce(context, new Runnable() {
                @Override
                public void run() {
                    try {
                        pr.finish();
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }
}
