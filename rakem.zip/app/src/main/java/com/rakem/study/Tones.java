package com.rakem.study;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** User-chosen sounds, copied into the app's private storage so they work offline and survive restarts. */
final class Tones {
    static final String ALARM = "alarm";
    static final String NOTIF = "notif";
    private static final long MAX_BYTES = 20L * 1024L * 1024L;

    private Tones() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("rakem_tones", Context.MODE_PRIVATE);
    }

    static File file(Context c, String kind) {
        return new File(c.getFilesDir(), "tone_" + kind);
    }

    static boolean has(Context c, String kind) {
        File f = file(c, kind);
        return f.exists() && f.length() > 0;
    }

    static String name(Context c, String kind) {
        return has(c, kind) ? prefs(c).getString("name_" + kind, "") : "";
    }

    static void clear(Context c, String kind) {
        file(c, kind).delete();
        prefs(c).edit().remove("name_" + kind).apply();
    }

    /** Copies the picked audio file. Returns its display name, or null on failure. */
    static String copyFrom(Context c, Uri uri, String kind) {
        String name = "";
        Cursor q = null;
        try {
            q = c.getContentResolver().query(uri, null, null, null, null);
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    name = q.getString(i);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (q != null) {
                q.close();
            }
        }
        File tmp = new File(c.getFilesDir(), "tone_" + kind + ".tmp");
        InputStream in = null;
        OutputStream out = null;
        try {
            in = c.getContentResolver().openInputStream(uri);
            if (in == null) {
                return null;
            }
            out = new FileOutputStream(tmp);
            byte[] buf = new byte[16384];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BYTES) {
                    out.close();
                    tmp.delete();
                    return "TOO_BIG";
                }
                out.write(buf, 0, n);
            }
            out.close();
            out = null;
            // make sure Android can really play it before we keep it
            MediaPlayer test = new MediaPlayer();
            try {
                test.setDataSource(tmp.getAbsolutePath());
                test.prepare();
            } catch (Exception e) {
                tmp.delete();
                return "BAD";
            } finally {
                test.release();
            }
            File dst = file(c, kind);
            dst.delete();
            if (!tmp.renameTo(dst)) {
                return null;
            }
            if (name == null || name.length() == 0) {
                name = "🎵";
            }
            prefs(c).edit().putString("name_" + kind, name).apply();
            return name;
        } catch (Exception e) {
            tmp.delete();
            return null;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    /** Plays the user's notification sound once (max ~9 s) and then releases it. */
    static void playNotifOnce(Context c, final Runnable done) {
        final Handler h = new Handler(Looper.getMainLooper());
        final MediaPlayer[] holder = new MediaPlayer[1];
        final boolean[] finished = new boolean[1];
        final Runnable end = new Runnable() {
            @Override
            public void run() {
                if (finished[0]) {
                    return;
                }
                finished[0] = true;
                try {
                    if (holder[0] != null) {
                        holder[0].release();
                    }
                } catch (Exception ignored) {
                }
                if (done != null) {
                    done.run();
                }
            }
        };
        try {
            MediaPlayer mp = new MediaPlayer();
            holder[0] = mp;
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setDataSource(file(c, NOTIF).getAbsolutePath());
            mp.prepare();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    h.post(end);
                }
            });
            mp.start();
            h.postDelayed(end, 9000);
        } catch (Exception e) {
            h.post(end);
        }
    }
}
