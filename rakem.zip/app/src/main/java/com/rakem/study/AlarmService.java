package com.rakem.study;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Rings loudly and keeps ringing until the user presses stop (safety limit: 30 minutes). */
public class AlarmService extends Service {
    static final String ACTION_STOP = "com.rakem.study.STOP_ALARM";
    static final int NOTIF_ID = 7001;
    private static final long MAX_MS = 30L * 60L * 1000L;
    static volatile boolean running = false;

    private MediaPlayer player;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private int prevVolume = -1;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = new Runnable() {
        @Override
        public void run() {
            stopRinging();
            stopForeground(true);
            stopSelf();
        }
    };

    static void start(Context c, String title, String body) {
        Intent i = new Intent(c, AlarmService.class);
        i.putExtra("title", title);
        i.putExtra("body", body);
        c.startForegroundService(i);
    }

    static void stop(Context c) {
        if (!running) {
            return;
        }
        Intent i = new Intent(c, AlarmService.class);
        i.setAction(ACTION_STOP);
        c.startService(i);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopRinging();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent == null ? "" : intent.getStringExtra("title");
        String body = intent == null ? "" : intent.getStringExtra("body");
        if (title == null) {
            title = "راكم ⏰";
        }
        if (body == null) {
            body = "";
        }
        Notification n = buildNotification(title, body);
        boolean first = !running;
        running = true;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (first) {
            startRinging();
        }
        handler.removeCallbacks(autoStop);
        handler.postDelayed(autoStop, MAX_MS);
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String title, String body) {
        Scheduler.ensureChannels(this);
        Intent screen = new Intent(this, AlarmActivity.class);
        screen.putExtra("title", title);
        screen.putExtra("body", body);
        screen.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent full = PendingIntent.getActivity(this, 1, screen,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, AlarmService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Action act = new Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_stat),
                "⏹ إيقاف", stopPi).build();

        return new Notification.Builder(this, Scheduler.CH_RING)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .addAction(act)
                .setWhen(System.currentTimeMillis())
                .build();
    }

    private void startRinging() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rakem:alarm");
                wakeLock.acquire(MAX_MS + 60000L);
            }
        } catch (Exception ignored) {
        }

        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audio != null) {
            try {
                prevVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM);
                audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            } catch (Exception e) {
                prevVolume = -1;
            }
            try {
                focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                        .setAudioAttributes(aa).build();
                audio.requestAudioFocus(focus);
            } catch (Exception ignored) {
            }
        }

        player = new MediaPlayer();
        boolean ok = false;
        try {
            player.setAudioAttributes(aa);
            if (Tones.has(this, Tones.ALARM)) {
                player.setDataSource(Tones.file(this, Tones.ALARM).getAbsolutePath());
            } else {
                player.setDataSource(this, defaultAlarmUri());
            }
            player.setLooping(true);
            player.setVolume(1f, 1f);
            player.prepare();
            player.start();
            ok = true;
        } catch (Exception e) {
            ok = false;
        }
        if (!ok) {
            // custom file failed: fall back to the phone's alarm sound
            try {
                player.reset();
                player.setAudioAttributes(aa);
                player.setDataSource(this, defaultAlarmUri());
                player.setLooping(true);
                player.setVolume(1f, 1f);
                player.prepare();
                player.start();
            } catch (Exception ignored) {
            }
        }

        try {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = new long[]{0, 700, 400, 700, 400, 700, 1500};
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0), aa);
            }
        } catch (Exception ignored) {
        }
    }

    private Uri defaultAlarmUri() {
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) {
            u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        if (u == null) {
            u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        }
        return u;
    }

    private void stopRinging() {
        handler.removeCallbacks(autoStop);
        try {
            if (player != null) {
                try {
                    player.stop();
                } catch (Exception ignored) {
                }
                player.release();
                player = null;
            }
        } catch (Exception ignored) {
        }
        try {
            if (vibrator != null) {
                vibrator.cancel();
            }
        } catch (Exception ignored) {
        }
        try {
            if (audio != null) {
                if (focus != null) {
                    audio.abandonAudioFocusRequest(focus);
                }
                if (prevVolume >= 0) {
                    audio.setStreamVolume(AudioManager.STREAM_ALARM, prevVolume, 0);
                }
            }
        } catch (Exception ignored) {
        }
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        }
        running = false;
        sendBroadcast(new Intent(AlarmActivity.ACTION_CLOSE).setPackage(getPackageName()));
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(NOTIF_ID);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        stopRinging();
        super.onDestroy();
    }
}
