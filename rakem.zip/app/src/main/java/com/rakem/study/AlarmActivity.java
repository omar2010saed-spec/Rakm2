package com.rakem.study;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Full-screen "stop the alarm" screen, shown even over the lock screen. */
public class AlarmActivity extends Activity {
    static final String ACTION_CLOSE = "com.rakem.study.CLOSE_ALARM_SCREEN";

    private final BroadcastReceiver closer = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        String title = getIntent().getStringExtra("title");
        String body = getIntent().getStringExtra("body");
        if (title == null) {
            title = "راكم ⏰";
        }
        if (body == null) {
            body = "";
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0F2E2C"));
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.parseColor("#F2C14E"));
        t.setTextSize(30);
        t.setGravity(Gravity.CENTER);
        root.addView(t, new LinearLayout.LayoutParams(-1, -2));

        TextView b = new TextView(this);
        b.setText(body);
        b.setTextColor(Color.WHITE);
        b.setTextSize(20);
        b.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(16);
        bp.bottomMargin = dp(40);
        root.addView(b, bp);

        Button stop = new Button(this);
        stop.setText("⏹  إيقاف المنبه");
        stop.setTextSize(24);
        stop.setTextColor(Color.parseColor("#0F2E2C"));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#F2C14E"));
        bg.setCornerRadius(dp(40));
        stop.setBackground(bg);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlarmService.stop(AlarmActivity.this);
                finish();
            }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(84));
        root.addView(stop, sp);

        Button open = new Button(this);
        open.setText("فتح التطبيق");
        open.setTextSize(16);
        open.setTextColor(Color.WHITE);
        open.setBackgroundColor(Color.TRANSPARENT);
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AlarmActivity.this, MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            }
        });
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, -2);
        op.topMargin = dp(16);
        root.addView(open, op);

        setContentView(root);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(closer, new IntentFilter(ACTION_CLOSE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(closer, new IntentFilter(ACTION_CLOSE));
        }
        if (!AlarmService.running) {
            finish();
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(closer);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
