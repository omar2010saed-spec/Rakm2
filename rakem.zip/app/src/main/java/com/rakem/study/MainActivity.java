package com.rakem.study;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_ALARM = 101;
    private static final int REQ_NOTIF = 102;
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Scheduler.ensureChannels(this);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(this), "RakemNative");
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    void pickSound(String kind) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        try {
            startActivityForResult(i, Tones.ALARM.equals(kind) ? REQ_ALARM : REQ_NOTIF);
        } catch (Exception e) {
            report(kind, "ERR", "");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_ALARM && requestCode != REQ_NOTIF) {
            return;
        }
        final String kind = requestCode == REQ_ALARM ? Tones.ALARM : Tones.NOTIF;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String r = Tones.copyFrom(MainActivity.this, uri, kind);
                if (r == null) {
                    report(kind, "ERR", "");
                } else if ("TOO_BIG".equals(r) || "BAD".equals(r)) {
                    report(kind, r, "");
                } else {
                    report(kind, "OK", r);
                }
            }
        }).start();
    }

    private void report(final String kind, final String status, final String name) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) {
                    return;
                }
                String js = "window.rakemSoundPicked&&window.rakemSoundPicked("
                        + JSONObject.quote(kind) + "," + JSONObject.quote(status) + "," + JSONObject.quote(name) + ");";
                web.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
